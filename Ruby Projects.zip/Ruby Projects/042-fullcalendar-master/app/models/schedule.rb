class Schedule < ApplicationRecord
  belongs_to :employee
end
